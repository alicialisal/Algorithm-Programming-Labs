totalharga = float(input("Masukkan total harga: "))
diskon = float(input("Masukkan diskon: "))
totalstlhdiskon = totalharga * ((100-diskon)/100)
print ("Total harga yang akan dibayar =", totalstlhdiskon)

