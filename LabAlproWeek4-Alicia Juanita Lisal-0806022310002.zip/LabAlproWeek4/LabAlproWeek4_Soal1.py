nama = input("Masukkan nama anda: ")
print("Halo, perkenalkan nama saya", nama)