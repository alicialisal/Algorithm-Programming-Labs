alas = float(input("Masukkan alas segitiga: "))
tinggi = float(input("Masukkan tinggi segitiga: "))
luas = alas * tinggi * 0.5
print("Luas segitiga adalah:", luas)