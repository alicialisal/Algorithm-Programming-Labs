import math

d1 = 4
sisi = float(input("Masukkan s = "))
d2 = math.sqrt((sisi**2) - (d1**2))
print ("Nilai d2 =", d2)
luas = ((d1*2) * (d2*2))/2
print ("Luas belah ketupat =", luas)